//
//  NJKAssetBrowserController.h
//  NJKImagePickerDemo
//
//  Created by JiakaiNong on 16/2/16.
//  Copyright © 2016年 poco. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NJKAssetBrowserController : UIViewController

@property (nonatomic, assign) NSInteger currentIndex;
@property (nonatomic, strong) NSArray *assetsArray;

@end
