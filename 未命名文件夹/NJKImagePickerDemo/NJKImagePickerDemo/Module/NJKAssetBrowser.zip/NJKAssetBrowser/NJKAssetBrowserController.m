//
//  NJKAssetBrowserController.m
//  NJKImagePickerDemo
//
//  Created by JiakaiNong on 16/2/16.
//  Copyright © 2016年 poco. All rights reserved.
//

#import "NJKAssetBrowserController.h"
#import "ImageDataAPI.h"
#import "NJKAssetBrowserCell.h"

@interface NJKAssetBrowserController () <UIScrollViewDelegate>

@property (nonatomic, strong) NSMutableSet *visibleViews;
@property (nonatomic, strong) NSMutableSet *reusedViews;
@property (nonatomic, weak) UIScrollView *scrollView;

@end

@implementation NJKAssetBrowserController

#pragma mark - Life Cycle

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 添加UIScrollView
    [self setupScrollView];
}

#pragma mark Init Views

// 添加UIScrollView
- (void)setupScrollView {
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    scrollView.pagingEnabled = YES;
    scrollView.delegate = self;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.contentSize = CGSizeMake(self.assetsArray.count * CGRectGetWidth(scrollView.frame), 0);
    scrollView.contentOffset = CGPointMake(self.currentIndex * self.view.frame.size.width, 0);
    [self.view addSubview:scrollView];
    _scrollView = scrollView;
    [self showImageAtIndex:self.currentIndex];
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    [self showImages];
}

#pragma mark - Private Method

- (void)showImages {
    
    // 获取当前处于显示范围内的图片的索引
    CGRect visibleBounds = self.scrollView.bounds;
    CGFloat minX = CGRectGetMinX(visibleBounds);
    CGFloat maxX = CGRectGetMaxX(visibleBounds);
    CGFloat width = CGRectGetWidth(visibleBounds);
    
    NSInteger firstIndex = (NSInteger)floorf(minX / width);
    NSInteger lastIndex  = (NSInteger)floorf(maxX / width);
    
    // 处理越界的情况
    if (firstIndex < 0) {
        firstIndex = 0;
    }
    
    if (lastIndex >= [self.assetsArray count]) {
        lastIndex = [self.assetsArray count] - 1;
    }
    
    // 回收不再显示的ImageView
    NSInteger cellIndex = 0;
    for (NJKAssetBrowserCell *cell in self.visibleViews) {
        cellIndex = cell.tag;
        // 不在显示范围内
        if (cellIndex < firstIndex || cellIndex > lastIndex) {
            cell.imageView.image = nil;
            [self.reusedViews addObject:cell];
            [cell removeFromSuperview];
        }
    }
    
    [self.visibleViews minusSet:self.reusedViews];
    
    // 是否需要显示新的视图
    for (NSInteger index = firstIndex; index <= lastIndex; index++) {
        BOOL isShow = NO;
        
        for (NJKAssetBrowserCell *cell in self.visibleViews) {
            if (cell.tag == index) {
                isShow = YES;
            }
        }
        
        if (!isShow) {
            [self showImageAtIndex:index];
        }
    }
}

// 显示一个图片view
- (void)showImageAtIndex:(NSInteger)index {
    
    NJKAssetBrowserCell *cell = [self.reusedViews anyObject];
    
    if (cell) {
        [self.reusedViews removeObject:cell];
    } else {
        cell = [[NJKAssetBrowserCell alloc] init];
        cell.userInteractionEnabled = YES;
    }
    
    CGRect cellFrame = self.scrollView.bounds;
    cellFrame.origin.x = CGRectGetWidth(cellFrame) * index;
    cell.tag = index;
    cell.frame = cellFrame;
    //GCD
    AlbumObj *obj = self.assetsArray[index];
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [[ImageDataAPI sharedInstance] getImageForPhotoObj:obj
                                                      withSize:cellFrame.size
                                                    completion:^(BOOL ret, UIImage *image)
         {
             //         NSLog(@"%@",NSStringFromCGSize(cell.assetImageView.frame.size));
             dispatch_async(dispatch_get_main_queue(), ^{
                 cell.imageView.image = image;
             });
         }];
    });
    
    [self.visibleViews addObject:cell];
    [self.scrollView addSubview:cell];
}

#pragma mark - Getters and Setters

- (NSMutableSet *)visibleViews {
    if (_visibleViews == nil) {
        _visibleViews = [[NSMutableSet alloc] init];
    }
    return _visibleViews;
}

- (NSMutableSet *)reusedViews {
    if (_reusedViews == nil) {
        _reusedViews = [[NSMutableSet alloc] init];
    }
    return _reusedViews;
}

@end

