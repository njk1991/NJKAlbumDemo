//
//  NJKAssetBrowserCell.m
//  NJKImagePickerDemo
//
//  Created by JiakaiNong on 16/2/17.
//  Copyright © 2016年 poco. All rights reserved.
//

#import "NJKAssetBrowserCell.h"

@implementation NJKAssetBrowserCell

- (instancetype)init {
    if (self = [super init]) {
        self.clipsToBounds = YES;
        self.showsHorizontalScrollIndicator = NO;
        self.showsVerticalScrollIndicator = NO;
        self.minimumZoomScale = 3;
        self.maximumZoomScale = 1;
        [self initImageView];
    }
    return self;
}

- (void)initImageView {
    self.imageView = [[UIImageView alloc] init];
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;
    self.imageView.backgroundColor = [UIColor blackColor];
    self.imageView.userInteractionEnabled = YES;
    [self addSubview:self.imageView];
}

- (void)setImageView:(UIImageView *)imageView {
    _imageView = imageView;
    self.contentSize = imageView.frame.size;
}

- (void)setFrame:(CGRect)frame {
    [super setFrame:frame];
    self.imageView.frame = self.bounds;
}

@end
